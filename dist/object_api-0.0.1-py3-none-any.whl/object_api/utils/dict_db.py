# TODO: it should store everything outside of the db
