class InvalidIndexError(ValueError):
    """Raised when an index is invalid"""

    pass
